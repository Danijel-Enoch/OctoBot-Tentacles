Poloniex is a basic RestExchange adaptation for Poloniex exchange. 
