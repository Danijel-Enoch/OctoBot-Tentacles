Bingx is a RestExchange adaptation for Bingx exchange using the REST API. 
