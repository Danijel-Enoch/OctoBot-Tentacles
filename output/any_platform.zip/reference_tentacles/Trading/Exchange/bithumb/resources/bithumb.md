Bithumb is a basic RestExchange adaptation for Bithumb exchange. 
