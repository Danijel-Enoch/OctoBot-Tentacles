Bitget is a RestExchange adaptation for Bitget exchange using the REST API. 
