Hollaex is a basic RestExchange adaptation for Hollaex exchange. 

Change the api url to connect to a specific hollaex exchange
