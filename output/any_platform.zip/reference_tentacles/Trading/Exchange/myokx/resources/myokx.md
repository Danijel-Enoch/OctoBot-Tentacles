Okx is a basic RestExchange adaptation for MyOKX exchange. 
