Bybit is a basic RestExchange adaptation for Bybit exchange.
