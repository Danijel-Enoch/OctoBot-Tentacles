Bitstamp is a basic RestExchange adaptation for Bitstamp exchange. 
