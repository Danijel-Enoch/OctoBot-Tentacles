HTX is a basic RestExchange adaptation for HTX exchange. 
