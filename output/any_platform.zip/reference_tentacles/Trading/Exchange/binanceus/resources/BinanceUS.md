BinanceUS is a RestExchange adaptation for Binance US exchange using the REST API. 
