Bitmex is a basic RestExchange adaptation for Bitmex exchange. 
