coinex is a basic RestExchange adaptation for coinex exchange. 
